import React from 'react'

const MockComponent = (props) => {
  return (
    <div>{props.message}</div>
  )
}

export default MockComponent