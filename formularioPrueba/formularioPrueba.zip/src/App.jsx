import { useState } from 'react'
import Rejuvenecer from './components/Rejuvenecer'
import FormComponent from './components/FormComponent'
function App() {

  return (
    <div >
        <FormComponent/>
    </div>
  )
}

export default App
